# DS4 Control — proyecto inicial para Android

Proyecto Android nativo en Kotlin con botones para:
- Buscar mandos conectados.
- Consultar si Android expone un vibrador para el mando.
- Probar una vibración de 300 ms o 1,5 s.
- Detener la vibración si el controlador la admite.
- Reproducir un tono de prueba en el TELÉFONO (esto NO es el altavoz interno del DS4).

## Importante sobre el DualShock 4
Android puede detectar el DS4 como mando de juego sin exponer sus motores mediante la API estándar. Si aparece “Android no expone un vibrador”, esta app no puede forzar la vibración con ese método.

El altavoz interno del DS4 no suele estar disponible como una salida de audio Bluetooth genérica en Android. El botón “Probar audio del teléfono” solo reproduce sonido en el móvil; no afirma enviar sonido al mando. Para usar el altavoz del DS4 haría falta implementar y comprobar el protocolo Bluetooth específico del mando, algo que este prototipo todavía no hace.

## Cómo abrirlo
1. Instala AndroidIDE u otro IDE Android compatible en tu teléfono, o copia el proyecto a un PC con Android Studio.
2. Abre la carpeta del proyecto.
3. Deja que Gradle sincronice y crea una APK de depuración.
4. Instala la APK y conecta el DS4 por Bluetooth antes de probar.

Configuración: Android Gradle Plugin 8.6.1, Gradle 8.7, Kotlin 2.0.20, `minSdk 26`, `compileSdk 35`.
