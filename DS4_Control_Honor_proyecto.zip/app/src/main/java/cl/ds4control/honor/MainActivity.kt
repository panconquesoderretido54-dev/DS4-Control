package cl.ds4control.honor

import android.app.Activity
import android.os.Bundle
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.media.AudioManager
import android.media.ToneGenerator

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var tone: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "🎮 DS4 CONTROL"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWidth())

        val subtitle = TextView(this).apply {
            text = "Pruebas para DualShock 4 por Bluetooth"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }
        root.addView(subtitle, matchWidth())

        status = TextView(this).apply {
            text = "Pulsa «Buscar mando» con el DS4 conectado."
            textSize = 16f
            setPadding(12, 14, 12, 14)
        }
        root.addView(status, matchWidth())

        addButton(root, "🔎 Buscar mando", ::findController)
        addButton(root, "〰️ Vibración corta (300 ms)") {
            vibrateController(300)
        }
        addButton(root, "💥 Vibración larga (1,5 s)") {
            vibrateController(1500)
        }
        addButton(root, "⏹ Detener vibración") {
            val device = findGameController(false)
            if (device != null && device.vibrator.hasVibrator()) {
                device.vibrator.cancel()
                status.text = "Se envió la orden de detener la vibración."
            } else {
                status.text = "No hay un vibrador del mando accesible por la API estándar."
            }
        }
        addButton(root, "🔊 Probar audio del teléfono") {
            try {
                tone?.release()
                tone = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 500)
                status.text = "Tono enviado a la salida de audio del teléfono; no al altavoz interno del DS4."
            } catch (e: Exception) {
                status.text = "No se pudo reproducir el tono: ${e.message ?: "error desconocido"}"
            }
        }

        val note = TextView(this).apply {
            text = "Nota: que Android detecte el mando no garantiza acceso a sus motores. El botón de audio prueba el móvil, no el altavoz del mando."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }
        root.addView(note, matchWidth())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            setOnClickListener { action() }
        }
        parent.addView(button, matchWidth())
    }

    private fun findGameController(showStatus: Boolean = true): InputDevice? {
        val devices = InputDevice.getDeviceIds()
            .mapNotNull { InputDevice.getDevice(it) }
            .filter {
                !it.isVirtual &&
                (it.sources and InputDevice.SOURCE_GAMEPAD != 0 ||
                 it.sources and InputDevice.SOURCE_JOYSTICK != 0)
            }

        val ds4 = devices.firstOrNull {
            val label = (it.name ?: "").lowercase()
            label.contains("wireless controller") ||
            label.contains("dualshock") ||
            label.contains("playstation")
        }
        val selected = ds4 ?: devices.firstOrNull()

        if (showStatus) {
            status.text = when {
                selected == null -> "No encontré un mando de juego. Comprueba que el DS4 esté conectado por Bluetooth y vuelve a buscar."
                else -> "Mando detectado: ${selected.name}\nID: ${selected.id}\nVibrador expuesto por Android: ${selected.vibrator.hasVibrator()}"
            }
        }
        return selected
    }

    private fun findController() {
        findGameController(true)
    }

    private fun vibrateController(durationMs: Long) {
        val device = findGameController(false)
        if (device == null) {
            status.text = "No encontré un mando. Conecta el DS4 y pulsa «Buscar mando»."
            return
        }

        val vibrator = device.vibrator
        if (!vibrator.hasVibrator()) {
            status.text = "Android detecta «${device.name}», pero no expone un vibrador para este mando. Esta vía no puede activarlo."
            return
        }

        try {
            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    durationMs,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
            status.text = "Orden de vibración enviada a ${device.name}. ¿Vibró el mando?"
        } catch (e: Exception) {
            status.text = "Android no pudo activar el vibrador: ${e.message ?: "error desconocido"}"
        }
    }

    override fun onDestroy() {
        tone?.release()
        tone = null
        super.onDestroy()
    }
}
