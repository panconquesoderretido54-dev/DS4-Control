plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cl.ds4control.honor"
    compileSdk = 35

    defaultConfig {
        applicationId = "cl.ds4control.honor"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1"
    }
}
